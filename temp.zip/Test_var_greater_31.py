a = 5
qwdhvsdhvsivoasvpsavdsuavpasbvpabbvbnndfghjsdfghsdfghsdfghsdfgsie = 0
asdhsbfhdsg = 0

